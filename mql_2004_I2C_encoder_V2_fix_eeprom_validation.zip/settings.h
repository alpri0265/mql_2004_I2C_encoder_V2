#pragma once
#include "types.h"

extern Settings S;

void settingsLoad();
void settingsSave();
void settingsLoadDefaults();
