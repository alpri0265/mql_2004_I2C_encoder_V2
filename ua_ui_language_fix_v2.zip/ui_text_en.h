#pragma once
// TODO: English UI strings table (future)
