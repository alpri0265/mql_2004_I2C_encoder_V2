#pragma once
#include "types.h"

int32_t recoGetRecFlow_x100(Material mat, uint8_t dia_mm, uint16_t al_factor_x100);
