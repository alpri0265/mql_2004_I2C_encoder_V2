#pragma once

// ========================
// UI Texts (EN / ASCII)
// ========================

// Common short labels
#define TXT_ON_CONT             "CONT"
#define TXT_OFF                 "OFF"
#define TXT_MENU                "MENU"
#define TXT_MENU_EDIT           "MENU (EDIT)"
#define TXT_MENU_ABORT          "MENU:Abort"
#define TXT_PULSE               "PULSE"

// Materials (menu/wizard)
#define TXT_MAT_STEEL           "Steel"
#define TXT_MAT_ALUMINUM        "Aluminum"
#define TXT_MAT_ALUM_SHORT      "Alum"

// Wizard titles
#define TXT_WIZ_MATERIAL        "WIZARD: MATERIAL"
#define TXT_WIZ_DIAMETER        "WIZARD: CUTTER O"
#define TXT_WIZ_RECOMMEND       "WIZARD: RECOMMEND"

// Run/Ready help lines
#define TXT_HINT_READY          "OK:Menu  START:Run"
#define TXT_HINT_WIZ_NEXT       "OK:Next  MENU:Back"
#define TXT_HINT_START_TOGGLE   "START:Toggle  OK:Menu"

// Calibration screens
#define TXT_CAL_RUN_TITLE       "CALIBRATION RUN"
#define TXT_CAL_ENTER_TITLE     "CAL: ENTER ml/60s"
#define TXT_CAL_DIGIT_PREFIX    "Digit: %u"
#define TXT_CAL_TURN_CHANGE     "Turn: change"
#define TXT_CAL_TURN_OK_NEXT    "Turn:chg OK:Next MENU"

// Generic formatted labels used in UI rendering
#define TXT_FMT_MODE            "Mode:%s"
#define TXT_FMT_MATERIAL        "Mat:%s  O:%umm"
#define TXT_FMT_REC_LINE        "Rec:%ld.%02ld  %s"
#define TXT_FMT_REC_U           "Rec: %ld.%02ld u"
#define TXT_FMT_SET_U           "Set: %ld.%02ld u"
#define TXT_FMT_SET_LINE        "Set:%ld.%02ld  O:%u"
#define TXT_FMT_VALUE_ML        "Value: %ld.%02ld ml"
#define TXT_FMT_TOTAL_SEC       "Total: %us"
#define TXT_FMT_LEFT_SEC        "Left : %us"
#define TXT_FMT_DIAM_MM         "> %umm"
#define TXT_FMT_ARROW_NAME      "> %s"

// Menu (settings) formatted labels
#define TXT_FMT_MODE_MENU       "Mode: %s"
#define TXT_FMT_MATERIAL_MENU   "Material: %s"
#define TXT_FMT_CUTTER_DIAM     "Cutter O: %umm"

#define TXT_MENU_CAL_60         "Calibrate 60s"
#define TXT_MENU_CAL_120        "Calibrate 120s"
#define TXT_MENU_CAL_CLEAR      "Clear calibration"
#define TXT_MENU_SAVE_EEPROM    "Save EEPROM"
#define TXT_MENU_LOAD_DEFAULTS  "Load Defaults"

#define TXT_FMT_CAL_NONE        "Cal ml/u: (none)"
#define TXT_FMT_CAL_VALUE       "Cal ml/u: %lu.%02lu"

#define TXT_FMT_KMIN            "Kmin: %u.%02u"
#define TXT_FMT_KMAX            "Kmax: %u.%02u"
#define TXT_FMT_AL_FACTOR       "AlFactor: %u.%02u"

#define TXT_FMT_POT_AVG_N       "POT Avg N: %u"
#define TXT_FMT_POT_HYST        "POT Hyst: %u.%02u"
#define TXT_FMT_PULSE_ON        "Pulse ON: %ums"
#define TXT_FMT_PULSE_OFF       "Pulse OFF: %ums"
#define TXT_FMT_PUMP_GAIN       "PumpGain: %lu"
