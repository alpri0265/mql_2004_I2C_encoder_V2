#pragma once

// ========================
// UI Texts (UA / UTF-8)
// Recommended: UPPERCASE
// ========================

// Common short labels
#define TXT_ON_CONT             "ПРОД"
#define TXT_OFF                 "ВИМК"
#define TXT_MENU                "МЕНЮ"
#define TXT_MENU_EDIT           "МЕНЮ (ПРАВКА)"
#define TXT_MENU_ABORT          "МЕНЮ:СТОП"
#define TXT_PULSE               "ІМПУЛЬС"

// Materials (menu/wizard)
#define TXT_MAT_STEEL           "СТАЛЬ"
#define TXT_MAT_ALUMINUM        "АЛЮМІНІЙ"
#define TXT_MAT_ALUM_SHORT      "АЛЮМ"

// Wizard titles
#define TXT_WIZ_MATERIAL        "МАЙСТЕР: МАТЕРІАЛ"
#define TXT_WIZ_DIAMETER        "МАЙСТЕР: ДІАМЕТР"
#define TXT_WIZ_RECOMMEND       "МАЙСТЕР: РЕКОМЕНД"

// Run/Ready help lines
#define TXT_HINT_READY          "OK:МЕНЮ START:ПУСК"
#define TXT_HINT_WIZ_NEXT       "OK:ДАЛІ  МЕНЮ:НАЗАД"
#define TXT_HINT_START_TOGGLE   "START:ЗМІНА OK:МЕНЮ"

// Calibration screens
#define TXT_CAL_RUN_TITLE       "КАЛІБРУВАННЯ"
#define TXT_CAL_ENTER_TITLE     "ВВІД: МЛ/60С"
#define TXT_CAL_DIGIT_PREFIX    "РОЗРЯД: %u"
#define TXT_CAL_TURN_CHANGE     "КРУТИ: ЗМІНА"
#define TXT_CAL_TURN_OK_NEXT    "КРУТИ OK:ДАЛІ МЕНЮ"

// Generic formatted labels used in UI rendering
#define TXT_FMT_MODE            "РЕЖИМ:%s"
#define TXT_FMT_MATERIAL        "МАТ:%s  D:%umm"
#define TXT_FMT_REC_LINE        "РЕК:%ld.%02ld  %s"
#define TXT_FMT_REC_U           "РЕК: %ld.%02ld u"
#define TXT_FMT_SET_U           "ЗАД: %ld.%02ld u"
#define TXT_FMT_SET_LINE        "ЗАД:%ld.%02ld  D:%u"
#define TXT_FMT_VALUE_ML        "ЗНАЧ: %ld.%02ld МЛ"
#define TXT_FMT_TOTAL_SEC       "ВСЬОГО: %us"
#define TXT_FMT_LEFT_SEC        "ЗАЛИШ: %us"
#define TXT_FMT_DIAM_MM         "> %umm"
#define TXT_FMT_ARROW_NAME      "> %s"

// Menu (settings) formatted labels
#define TXT_FMT_MODE_MENU       "РЕЖИМ: %s"
#define TXT_FMT_MATERIAL_MENU   "МАТЕРІАЛ: %s"
#define TXT_FMT_CUTTER_DIAM     "ДІАМЕТР: %umm"

#define TXT_MENU_CAL_60         "КАЛІБР 60С"
#define TXT_MENU_CAL_120        "КАЛІБР 120С"
#define TXT_MENU_CAL_CLEAR      "ОЧИСТИТИ КАЛІБР"
#define TXT_MENU_SAVE_EEPROM    "ЗБЕРЕГТИ EEPROM"
#define TXT_MENU_LOAD_DEFAULTS  "ЗАВАНТ. ТИПОВЕ"

#define TXT_FMT_CAL_NONE        "КАЛ МЛ/U: (НЕМА)"
#define TXT_FMT_CAL_VALUE       "КАЛ МЛ/U: %lu.%02lu"

#define TXT_FMT_KMIN            "KMIN: %u.%02u"
#define TXT_FMT_KMAX            "KMAX: %u.%02u"
#define TXT_FMT_AL_FACTOR       "ALFACT: %u.%02u"

#define TXT_FMT_POT_AVG_N       "POT AVG N: %u"
#define TXT_FMT_POT_HYST        "POT HYST: %u.%02u"
#define TXT_FMT_PULSE_ON        "ІМП ON: %ums"
#define TXT_FMT_PULSE_OFF       "ІМП OFF: %ums"
#define TXT_FMT_PUMP_GAIN       "PUMPGAIN: %lu"
