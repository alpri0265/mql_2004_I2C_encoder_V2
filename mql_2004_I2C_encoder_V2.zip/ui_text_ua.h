#pragma once
// TODO: Ukrainian UI strings table (future)
